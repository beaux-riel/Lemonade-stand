import{g as e}from"./vendor-react-gkcTQpZ_.js";var o,t;const r=e(t?o:(t=1,o=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")})),n=Object.freeze(Object.defineProperty({__proto__:null,default:r},Symbol.toStringTag,{value:"Module"}));export{n as b};
//# sourceMappingURL=browser-siT2aezh.js.map
