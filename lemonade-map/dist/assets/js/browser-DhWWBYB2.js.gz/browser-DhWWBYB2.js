import{g as e}from"./vendor-react-CDe1t649.js";const o=e((function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")})),t=Object.freeze(Object.defineProperty({__proto__:null,default:o},Symbol.toStringTag,{value:"Module"}));export{t as b};
//# sourceMappingURL=browser-DhWWBYB2.js.map
